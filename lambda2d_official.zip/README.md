
# Lambda 2D – Projeto Mobile Oficial

## Como gerar o APK pelo GitHub (sem PC)
1. Crie um repositório no GitHub.
2. Envie todos os arquivos deste ZIP.
3. Vá em **Actions** → **Build Android APK**.
4. Clique em **Run workflow**.
5. Baixe o APK em **Artifacts**.

O app inclui:
- Ícone oficial λ
- Splash screen
- Controles touch
- Phaser 3 otimizado para Android
